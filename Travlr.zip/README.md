# Module 2 - Travlr  

## Overview  
This module sets up routing, controllers, and views using Express and Handlebars.  

## Features  
- Express routing ('index', 'travel', 'meals', 'news', 'rooms', 'contact', 'about')  
- Handlebars templating with partials 
